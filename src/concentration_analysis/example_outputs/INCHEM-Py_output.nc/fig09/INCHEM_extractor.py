# -*- coding: utf-8 -*-
"""
Output extraction and plotting script for INCHEM-Py. 
A detailed description of this file can be found within the user manual.

Copyright (C) 2019-2021 
David Shaw : david.shaw@york.ac.uk
Nicola Carslaw : nicola.carslaw@york.ac.uk

All rights reserved.

This file is additional to INCHEM-Py.

INCHEM-Py is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

INCHEM-Py is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with INCHEM-Py.  If not, see <https://www.gnu.org/licenses/>.

This script inputs the out_data.pickle files from model runs of INCHEM-Py
from specified output directories, saves and plots the species given in
species_to_plot in a csv and a png respectively. These are saved in the 
output_folder 
"""
import pandas as pd


'''
Variables to change
'''
#directories of data to extract and plot
out_directories=['INCHEM-photoout']

#species to extract and plot
species_to_extract=['cosx']
#All species will be saved to a seperate csv for each input directory.
#A maximum of three seperate graphs will be made; species concentrations, 
#reactivity, and production. 

#times to plot from and to
start_time = 0*3600
end_time = (48*3600)

scale = "hours"
#can be "hours", "minutes", "seconds"

#folder to save csv and png graphs to output_folder. Can already exist or
#it will be created
output_folder = "Comparison"

#should the y scale be log or not
log_plot = False

labels = iter(["INCHEM-Py", "AtCHEM2"]) #"AtCHEM2 (SPGMR)",

ppb = False

'''
Extract and plot the data
'''
#import required packages
import pickle

import os
import matplotlib.pyplot as plt
import numpy as np

#define dictionary of output dataframes from out_directories
out_data={}
for i in out_directories:
    print(i)
    with open("%s/out_data.pickle" % i,'rb') as handle:
        out_data[i]=pd.read_pickle(handle)
        
#out_data['AtCHEM1'] = pd.read_csv("model_1/speciesConcentrations.output", sep="\s+",index_col=0)
out_data['AtCHEM3'] = pd.read_csv("model_1_long0/speciesConcentrations.output", sep="\s+",index_col=0)

out_data['AtCHEM3'] = pd.concat([out_data['AtCHEM3'],pd.read_csv("model_1_long0/environmentVariables.output", sep="\s+",index_col=0)
                                 ,pd.read_csv("model_1_long0/photolysisRatesParameters.output", sep="\s+",index_col=0)
                                 ,pd.read_csv("model_1_long0/photolysisRates.output", sep="\s+",index_col=0)],axis=1)

#out_data['AtCHEM3'].index = out_data['AtCHEM3'].index-120

#get the current working directory and create the output folder 
#if it doesn't exist        
path=os.getcwd()
if not os.path.exists('%s/%s' % (path,output_folder)):
    os.mkdir('%s/%s' % (path,output_folder))

#create and save csvs
for i in out_data:
    out_data[i].to_csv("%s/%s/%s.csv" % (path,output_folder,i), 
                       columns = species_to_extract)
    
#plotting function
def plotting_function(plot_species,out_data,units,start_time,end_time,name,log_plot,ppb):
    #figure resolution and size
    plt.figure(dpi=600,figsize=(8,4))
    
    #set time conversion factor and labels
    if scale == "hours":
        factor = 3600
        plt.xlabel("Time (hours)")
    elif scale == "minutes":
        factor = 60
        plt.xlabel("Time (mins)")
    else:
        factor = 1
        plt.xlabel("Time (mins)")
        
    if name == 'Concentration' and ppb == True:
        conversion = 2.46e10
    else:
        conversion = 1
    
    #unique colours
    colour=iter(['#377eb8', '#ff7f00', '#4daf4a',
                  '#f781bf', '#a65628', '#984ea3',
                  '#999999', '#e41a1c', '#dede00'])
    
    for k in out_data:
        time_step = out_data[k].index[1]-out_data[k].index[0]
        start_time = int( time_step * round( start_time / time_step ))
        end_time = int( time_step * round( end_time / time_step ))
        for l in plot_species: 
            if len(out_directories) == 1:
                #label = "%s" % l
                label = next(labels)
                ncol = 5
            else:
                label="%s_%s" % (k,l)
                #label = labels[out_directories.index(k)]
                ncol = 2
            c=next(colour)
            plt.plot(list(out_data[k][l][start_time:end_time].index/factor),
                     list(out_data[k][l][start_time:end_time]/conversion),
                     label=label,c=c)
    if log_plot == True:
        if name != "Photolysis":        
            plt.yscale("log") #can be commented out for a non-log plot
    if ppb == True and name == "Concentration":
        plt.ylabel("Concentration (ppb)")
    else:        
        plt.ylabel(units)
    #plt.xlim((0,48))
    plt.legend(loc='upper center', bbox_to_anchor=(0.45, -0.15),
      fancybox=True, shadow=True, ncol=ncol)
    plt.savefig('%s/%s/out_graph_%s_%s.png' % (path,output_folder,name,species_to_extract),
                bbox_inches='tight')
    return None

#units for the graphs
units = ["Concentration (molecules/cm\N{SUPERSCRIPT THREE})",
"Reactivity (s\N{SUPERSCRIPT MINUS}\N{SUPERSCRIPT ONE})",
"Production (molecules/cm\N{SUPERSCRIPT THREE}s\N{SUPERSCRIPT MINUS}\N{SUPERSCRIPT ONE})",
"Photolysis coefficient (s\N{SUPERSCRIPT MINUS}\N{SUPERSCRIPT ONE})"]

#additional name for graphs
name = ['Concentration','Reactivity','Production','Photolysis']

photolysis_names = ['J%s' % x for x in range(75)]

#extract concentrations, production, and reactivity
production = []
reactivity = []
concentration = []
photolysis = []
for i in species_to_extract: 
    if i.endswith("production"):
        production.append(i)
    elif i.endswith("reactivity"):
        reactivity.append(i)
    elif i in photolysis_names:
        photolysis.append(i)
    else:
        concentration.append(i)
 
#plot graphs
#if len(production) > 0:
#    plotting_function(production,out_data,units[2],start_time,end_time,name[2],log_plot,ppb)
#if len(reactivity) > 0:
#    plotting_function(reactivity,out_data,units[1],start_time,end_time,name[1],log_plot,ppb)
#if len(concentration) > 0:
#    plotting_function(concentration,out_data,units[0],start_time,end_time,name[0],log_plot,ppb)
#if len(photolysis) > 0:
#    plotting_function(photolysis,out_data,units[3],start_time,end_time,name[3],log_plot,ppb)


'''compare results'''

#comparison_species = ['OH','O3','NO2','NO','HCHO','HO2']
comparison_species = ['cosx',]
labels = {'cosx':'Solar zenith angle',
          'OH':'OH',
          'O3':'O3',
          'NO2':'NO2',
          'NO':'NO',
          'HCHO':'HCHO',
          'HO2':'HO2'}
colour=iter(['#377eb8', '#ff7f00', '#4daf4a',
              '#f781bf', '#a65628', '#984ea3',
              '#999999', '#e41a1c', '#dede00'])

deviation = {}
for i in comparison_species:
    deviation[i] = ((out_data['INCHEM-photoout'][i]-out_data['AtCHEM3'][i])/max(out_data['AtCHEM3'][i]))*100
    print(i,'%.3E' % max(out_data['INCHEM-photoout'][i]) , '%.3E' % max(out_data['AtCHEM3'][i]), (((max(out_data['INCHEM-photoout'][i]) - max(out_data['AtCHEM3'][i]))/max(out_data['AtCHEM3'][i]))*100))

plt.figure(dpi=600,figsize=(8,2))
factor = 3600
plt.xlabel("Time (hours)")
for i in deviation:
    plt.plot(list(deviation[i].index/factor),
             list(deviation[i]),
             label=labels[i],c=next(colour))
plt.ylabel('Deviation (%)')
#plt.xlim((0,48))
plt.ylim((-2,4))
plt.legend(#loc='upper center', bbox_to_anchor=(0.45, -0.15),
           fancybox=True, shadow=True,ncols=3)

plt.savefig('%s/percentage_difference.png' % (output_folder),
            bbox_inches='tight')

comparison_species = ['OH','O3','NO2','NO','HCHO','HO2']
#comparison_species = ['cosx']

deviation = {}
for i in comparison_species:
    deviation[i] = ((out_data['INCHEM-photoout'][i]-out_data['AtCHEM3'][i])/max(out_data['AtCHEM3'][i]))*100
    print(i,'%.3E' % max(out_data['INCHEM-photoout'][i]) , '%.3E' % max(out_data['AtCHEM3'][i]), (((max(out_data['INCHEM-photoout'][i]) - max(out_data['AtCHEM3'][i]))/max(out_data['AtCHEM3'][i]))*100))

plt.figure(dpi=600,figsize=(8,2))
factor = 3600
plt.xlabel("Time (hours)")
for i in deviation:
    plt.plot(list(deviation[i].index/factor),
             list(deviation[i]),
             label=labels[i],c=next(colour))
plt.ylabel('Deviation (%)')
#plt.xlim((0,48))
plt.ylim((-2,4))
plt.legend(#loc='upper center', bbox_to_anchor=(0.45, -0.15),
           fancybox=True, shadow=True,ncols=3)

plt.savefig('%s/percentage_difference_2.png' % (output_folder),
            bbox_inches='tight')