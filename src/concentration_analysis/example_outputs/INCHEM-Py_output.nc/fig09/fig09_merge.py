# -*- coding: utf-8 -*-
"""
Created on Wed Apr  5 11:14:28 2023

@author: Dave
"""
from matplotlib import font_manager
from PIL import Image, ImageFont, ImageDraw

#Find the path for a specific font:
file = font_manager.findfont('DejaVu Sans')
#Load the font to pillow
textfont = ImageFont.truetype(file, 100)

a = "(a)"
b = "(b)"

top_graph = Image.open('Comparison/percentage_difference_2.png')
bottom_graph = Image.open('Comparison/percentage_difference.png')

im1_size = top_graph.size
im2_size = bottom_graph.size

fig = Image.new('RGB',(max([im1_size[0],im2_size[0]]), im1_size[1] + im2_size[1]),(255,255,255))
fig.paste(top_graph,(0,0))

diff = int((max([im1_size[0],im2_size[0]]) - min([im1_size[0],im2_size[0]]))/2)

fig.paste(bottom_graph,(diff,im1_size[1]))

ediatable_fig = ImageDraw.Draw(fig)
ediatable_fig.text((50,50),a,(0,0,0),font=textfont)
ediatable_fig.text((50,im1_size[1]+50),b,(0,0,0),font=textfont)

fig.save("fig09.png",'PNG')